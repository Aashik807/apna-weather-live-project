# Weather App 🌤️

A simple weather web app built with HTML, CSS, and JavaScript using the OpenWeatherMap API.

## 🔧 Features
- Search weather by city name
- Shows temperature, humidity, wind speed
- Simple, clean, responsive UI

## 🚀 How to Run
1. Replace `YOUR_API_KEY` in `script.js` with your OpenWeatherMap API key.
2. Open `index.html` in a browser.

## 📦 Tech Stack
- HTML
- CSS
- JavaScript (Fetch API)

## 📸 Screenshot
Add a screenshot here if needed.

---

✅ Made as a Live Project Assignment.
